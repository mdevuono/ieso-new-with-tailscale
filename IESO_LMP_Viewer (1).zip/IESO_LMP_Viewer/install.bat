@echo off
echo ============================================
echo  IESO LMP Viewer - Installer
echo ============================================
echo.
echo  Before continuing, make sure the following
echo  are installed on this machine:
echo.
echo  [1] Python (3.8 or newer)
echo      https://www.python.org/downloads/
echo      IMPORTANT: Check "Add Python to PATH"
echo      during installation.
echo.
echo  [2] Tailscale
echo      https://tailscale.com/download
echo      Sign in with the same account used on
echo      your other devices.
echo.
echo ============================================
echo.
pause
echo.

:: Check Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo         Download from https://www.python.org/downloads/
    echo         Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo [OK] Python found:
python --version
echo.

:: Create app folder in user's home directory
set INSTALL_DIR=%USERPROFILE%\IESO_LMP_Viewer
echo [INFO] Installing to: %INSTALL_DIR%
echo.

if not exist "%INSTALL_DIR%" (
    mkdir "%INSTALL_DIR%"
    echo [OK] Created folder: %INSTALL_DIR%
) else (
    echo [INFO] Folder already exists, updating files...
)

:: Create data subfolder
if not exist "%INSTALL_DIR%\data" (
    mkdir "%INSTALL_DIR%\data"
    echo [OK] Created data folder
)

:: Copy application files
copy /Y "%~dp0server.py" "%INSTALL_DIR%\server.py" >nul
copy /Y "%~dp0index.html" "%INSTALL_DIR%\index.html" >nul
copy /Y "%~dp0Start_LMP_Server.bat" "%INSTALL_DIR%\Start_LMP_Server.bat" >nul
echo [OK] Copied application files
echo.

:: Install Python dependencies
echo [INFO] Installing Python dependencies...
python -m pip install flask requests --quiet
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies.
    echo         Try running: python -m pip install flask requests
    pause
    exit /b 1
)
echo [OK] Dependencies installed
echo.

:: Create desktop shortcut for the launcher
echo [INFO] Creating desktop shortcut...
set SHORTCUT=%USERPROFILE%\Desktop\IESO LMP Viewer.lnk
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%INSTALL_DIR%\Start_LMP_Server.bat'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = 'C:\Windows\System32\SHELL32.dll,14'; $s.Description = 'Start IESO LMP Viewer Server'; $s.Save()"
echo [OK] Desktop shortcut created
echo.

echo ============================================
echo  Installation complete!
echo  
echo  To start the server:
echo    - Double-click "IESO LMP Viewer" on your desktop, OR
echo    - Run Start_LMP_Server.bat in %INSTALL_DIR%
echo  
echo  Then open your browser to:
echo    http://localhost:5000
echo ============================================
echo.
pause
